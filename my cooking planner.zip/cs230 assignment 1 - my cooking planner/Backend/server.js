const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());


const fridgeContents = ['eggs', 'milk', 'butter', 'flour', 'sugar', 'tomatoes', 'onions',];


app.post('/api/check-fridge', (req, res) => {
    try {
        const { ingredients } = req.body;
        if (!ingredients) throw new Error('No ingredients provided');
        
        const available = ingredients.filter(ing => fridgeContents.includes(ing));
        res.json({ available });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));