console.log("Script loaded!");

document.addEventListener('DOMContentLoaded', () => {
    const checkFridgeBtn = document.getElementById('check-fridge');
    
    if (!checkFridgeBtn) {
        console.error("Could not find check-fridge button!");
        return;
    }

    checkFridgeBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        console.log("Check Fridge button clicked");

        try {
 
            const ingredients = Array.from(document.querySelectorAll('[data-ingredient]'))
                .map(el => {
                    const ing = el.getAttribute('data-ingredient');
                    console.log(`Found ingredient: ${ing}`);
                    return ing;
                });
            
            console.log("Sending ingredients to server:", ingredients);

           
            const response = await fetch('http://localhost:3000/api/check-fridge', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ ingredients })
            });

            console.log("Response status:", response.status);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            console.log("Available ingredients:", data.available);

           
            updateIngredients(data.available);

        } catch (error) {
            console.error('Full error details:', error);
            alert('Error checking fridge. See console for details.');
        }
    });

    function updateIngredients(available) {
        console.log("Updating ingredient display...");
        
        document.querySelectorAll('[data-ingredient]').forEach(item => {
            const ingredient = item.getAttribute('data-ingredient');
            const isAvailable = available.includes(ingredient);
            
          
            item.setAttribute('data-available', isAvailable);
            
         
            const textOnly = item.textContent.replace(/[✓✗]\s?/, '').trim();
            item.textContent = textOnly;
            
            console.log(`- ${ingredient}: ${isAvailable ? 'Available' : 'Missing'}`);
        });
    }
});