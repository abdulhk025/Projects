const auth = async (req, res, next) => {
    try {
        // Allow the mock token
        if (req.header('Authorization') === 'Bearer mock-jwt-token-for-chris') {
            req.userId = 1; // Mock user ID
            return next();
        }

        const token = req.header('Authorization').replace('Bearer ', '');
        const decoded = jwt.verify(token, 'your_jwt_secret');
        
        req.userId = decoded.userId;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Please authenticate' });
    }
};

module.exports = auth;