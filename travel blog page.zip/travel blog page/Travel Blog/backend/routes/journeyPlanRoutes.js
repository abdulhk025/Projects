const express = require('express');
const router = express.Router();
const journeyPlanController = require('../controllers/journeyPlanController');
const authMiddleware = require('../middleware/auth');

// Make sure these controller functions exist
router.get('/', authMiddleware, journeyPlanController.getAllJourneyPlans);
router.post('/', authMiddleware, journeyPlanController.createJourneyPlan);
router.put('/:id', authMiddleware, journeyPlanController.updateJourneyPlan);
router.delete('/:id', authMiddleware, journeyPlanController.deleteJourneyPlan);

module.exports = router;