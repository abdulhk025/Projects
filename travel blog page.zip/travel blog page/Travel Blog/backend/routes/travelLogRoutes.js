const express = require('express');
const router = express.Router();
const travelLogController = require('../controllers/travelLogController');
const authMiddleware = require('../middleware/auth');

router.post('/', authMiddleware, travelLogController.createTravelLog);
router.get('/', authMiddleware, travelLogController.getAllTravelLogs);

module.exports = router;