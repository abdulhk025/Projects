const pool = require('../db');

const getAllJourneyPlans = async (req, res) => {
    try {
        const [plans] = await pool.query('SELECT * FROM JourneyPlans WHERE user_id = ?', [req.userId]);
        res.json(plans);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

const createJourneyPlan = async (req, res) => {
    const { name, locations, start_date, end_date, activities, description } = req.body;
    
    try {
        const [result] = await pool.query(
            'INSERT INTO JourneyPlans (user_id, name, locations, start_date, end_date, activities, description) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [req.userId, name, JSON.stringify(locations), start_date, end_date, JSON.stringify(activities), description]
        );
        
        const [newPlan] = await pool.query('SELECT * FROM JourneyPlans WHERE id = ?', [result.insertId]);
        res.status(201).json(newPlan[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

const updateJourneyPlan = async (req, res) => {
    const { id } = req.params;
    const { name, locations, start_date, end_date, activities, description } = req.body;
    
    try {
        await pool.query(
            'UPDATE JourneyPlans SET name = ?, locations = ?, start_date = ?, end_date = ?, activities = ?, description = ? WHERE id = ? AND user_id = ?',
            [name, JSON.stringify(locations), start_date, end_date, JSON.stringify(activities), description, id, req.userId]
        );
        
        const [updatedPlan] = await pool.query('SELECT * FROM JourneyPlans WHERE id = ?', [id]);
        res.json(updatedPlan[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

const deleteJourneyPlan = async (req, res) => {
    const { id } = req.params;
    
    try {
        await pool.query('DELETE FROM JourneyPlans WHERE id = ? AND user_id = ?', [id, req.userId]);
        res.json({ message: 'Journey plan deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

module.exports = {
    getAllJourneyPlans,
    createJourneyPlan,
    updateJourneyPlan,
    deleteJourneyPlan
};