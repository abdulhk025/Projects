const pool = require('../db');

const createTravelLog = async (req, res, next) => {
  const { title, description, start_date, end_date, tags } = req.body;
  
  if (!title || !start_date) {
    return res.status(400).json({ message: 'Title and start date are required' });
  }

  try {
    const tagsJson = JSON.stringify(tags || []);
    const [result] = await pool.query(
      'INSERT INTO TravelLogs (user_id, title, description, start_date, end_date, tags) VALUES (?, ?, ?, ?, ?, ?)',
      [req.userId, title, description, start_date, end_date, tagsJson]
    );
    
    const [newLog] = await pool.query('SELECT * FROM TravelLogs WHERE id = ?', [result.insertId]);
    res.status(201).json(newLog[0]);
  } catch (error) {
    console.error('Database error:', error);
    next(error); // Pass to error handler middleware
  }
};

const getAllTravelLogs = async (req, res, next) => {
  try {
    const [logs] = await pool.query('SELECT * FROM TravelLogs WHERE user_id = ?', [req.userId]);
    if (!logs.length) {
      return res.status(404).json({ message: 'No travel logs found' });
    }
    res.json(logs);
  } catch (error) {
    console.error(error);
    next(error); // Pass to error handler middleware
  }
};

module.exports = {
  createTravelLog,
  getAllTravelLogs
};