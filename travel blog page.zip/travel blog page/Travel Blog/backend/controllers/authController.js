const jwt = require('jsonwebtoken');

const login = async (req, res) => {
    const { username, password } = req.body;
    
    // Hardcoded credentials check
    if (username === 'Chris' && password === '123456') {
        // Create a mock user object
        const mockUser = {
            id: 1,
            username: 'Chris',
            email: 'chris@example.com',
            address: '123 Main St'
        };

        // Create token
        const token = jwt.sign(
            { userId: mockUser.id, username: mockUser.username },
            'your_jwt_secret',
            { expiresIn: '1h' }
        );
        
        return res.json({ 
            token,
            user: mockUser
        });
    } else {
        return res.status(401).json({ message: 'Invalid credentials. Use username: Chris, password: 123456' });
    }
};

module.exports = {
    login
};