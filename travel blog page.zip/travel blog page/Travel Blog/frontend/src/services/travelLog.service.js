import axios from 'axios';

const API_URL = 'http://localhost:5000/api/travel-logs';

const createTravelLog = async (logData, token) => {
    const response = await axios.post(API_URL, logData, {
        headers: { Authorization: `Bearer ${token}` }
    });
    return response.data;
};

const getTravelLogs = async (token) => {
    const response = await axios.get(API_URL, {
        headers: { Authorization: `Bearer ${token}` }
    });
    return response.data;
};

const travelLogService = {
    createTravelLog,
    getTravelLogs
};

export default travelLogService;