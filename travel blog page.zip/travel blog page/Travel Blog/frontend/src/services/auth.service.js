import axios from 'axios';

const API_URL = 'http://localhost:8080/api/auth/';

class AuthService {
  // Hardcoded test user for immediate access
  static getTestUser() {
    return {
      id: 1,
      username: 'testuser',
      email: 'test@example.com',
      accessToken: 'mock-token-for-immediate-access',
      address: '123 Test St'
    };
  }

  login(email, password) {
    // Bypass API call for test credentials
    if (email === 'test@example.com' && password === 'Test1234') {
      return Promise.resolve({ data: AuthService.getTestUser() });
    }

    return axios.post(API_URL + 'login', { email, password })
      .then(response => {
        if (response.data.accessToken) {
          localStorage.setItem('user', JSON.stringify(response.data));
        }
        return response.data;
      });
  }

  logout() {
    localStorage.removeItem('user');
  }

  getCurrentUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }
}

export default new AuthService();