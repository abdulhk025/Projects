import axios from 'axios';

const API_URL = 'http://localhost:8080/api/journey-plans/';

const getAuthHeader = () => {
  const user = JSON.parse(localStorage.getItem('user'));

  if (user && user.accessToken) {
    return { 'x-access-token': user.accessToken };
  } else {
    return {};
  }
};

const create = (name, locations, startDate, endDate, activities, description) => {
  return axios.post(API_URL, {
    name,
    locations,
    startDate,
    endDate,
    activities,
    description
  }, { headers: getAuthHeader() });
};

const getAll = () => {
  return axios.get(API_URL, { headers: getAuthHeader() });
};

const get = id => {
  return axios.get(API_URL + id, { headers: getAuthHeader() });
};

const update = (id, data) => {
  return axios.put(API_URL + id, data, { headers: getAuthHeader() });
};

const remove = id => {
  return axios.delete(API_URL + id, { headers: getAuthHeader() });
};

export default {
  create,
  getAll,
  get,
  update,
  remove
};