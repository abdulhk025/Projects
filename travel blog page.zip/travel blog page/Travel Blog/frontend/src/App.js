import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import TravelLogs from './pages/TravelLogs';
import JourneyPlans from './pages/JourneyPlans';
import Navbar from './components/Navbar';

function App() {
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);
  const [user, setUser] = React.useState(null);

  const handleLogin = (userData) => {
    setIsAuthenticated(true);
    setUser(userData);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('token');
  };

  return (
    <Router>
      {isAuthenticated && <Navbar onLogout={handleLogout} />}
      <Routes>
        <Route 
          path="/" 
          element={
            isAuthenticated ? 
            <Navigate to="/travel-logs" /> : 
            <Login onLogin={handleLogin} />
          } 
        />
        <Route 
          path="/travel-logs" 
          element={
            isAuthenticated ? 
            <TravelLogs user={user} /> : 
            <Navigate to="/" />
          } 
        />
        <Route 
          path="/journey-plans" 
          element={
            isAuthenticated ? 
            <JourneyPlans user={user} /> : 
            <Navigate to="/" />
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;