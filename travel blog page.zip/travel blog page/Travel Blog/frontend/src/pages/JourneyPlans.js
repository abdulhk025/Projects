import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const JourneyPlans = ({ user }) => {
  const [plans, setPlans] = useState([]);
  const [newPlan, setNewPlan] = useState({
    name: '',
    locations: [],
    start_date: '',
    end_date: '',
    activities: [],
    description: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [locationInput, setLocationInput] = useState('');
  const [activityInput, setActivityInput] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPlans = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:5000/api/journey-plans', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setPlans(response.data);
      } catch (err) {
        console.error(err);
        if (err.response?.status === 401) {
          navigate('/');
        }
      }
    };
    
    fetchPlans();
  }, [navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewPlan({ ...newPlan, [name]: value });
  };

  const handleAddLocation = () => {
    if (locationInput.trim()) {
      setNewPlan({
        ...newPlan,
        locations: [...newPlan.locations, locationInput.trim()]
      });
      setLocationInput('');
    }
  };

  const handleRemoveLocation = (index) => {
    const updatedLocations = newPlan.locations.filter((_, i) => i !== index);
    setNewPlan({ ...newPlan, locations: updatedLocations });
  };

  const handleAddActivity = () => {
    if (activityInput.trim()) {
      setNewPlan({
        ...newPlan,
        activities: [...newPlan.activities, activityInput.trim()]
      });
      setActivityInput('');
    }
  };

  const handleRemoveActivity = (index) => {
    const updatedActivities = newPlan.activities.filter((_, i) => i !== index);
    setNewPlan({ ...newPlan, activities: updatedActivities });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      
      if (editingId) {
        await axios.put(`http://localhost:5000/api/journey-plans/${editingId}`, newPlan, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } else {
        await axios.post('http://localhost:5000/api/journey-plans', newPlan, {
          headers: { Authorization: `Bearer ${token}` }
        });
      }
      
      // Refresh plans
      const response = await axios.get('http://localhost:5000/api/journey-plans', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPlans(response.data);
      
      // Reset form
      setNewPlan({
        name: '',
        locations: [],
        start_date: '',
        end_date: '',
        activities: [],
        description: ''
      });
      setEditingId(null);
    } catch (err) {
      console.error(err);
    }
  };

  const handleEdit = (plan) => {
    setNewPlan({
      name: plan.name,
      locations: plan.locations ? JSON.parse(plan.locations) : [],
      start_date: plan.start_date,
      end_date: plan.end_date,
      activities: plan.activities ? JSON.parse(plan.activities) : [],
      description: plan.description
    });
    setEditingId(plan.id);
  };

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/journey-plans/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      // Refresh plans
      const response = await axios.get('http://localhost:5000/api/journey-plans', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPlans(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Journey Plans</h2>
      <h3>Welcome, {user?.username}!</h3>
      
      <form onSubmit={handleSubmit} style={{ marginBottom: '30px', padding: '20px', border: '1px solid #ddd', borderRadius: '5px' }}>
        <h3>{editingId ? 'Edit Plan' : 'Add New Plan'}</h3>
        <div style={{ marginBottom: '10px' }}>
          <label>Plan Name:</label>
          <input
            type="text"
            name="name"
            value={newPlan.name}
            onChange={handleInputChange}
            required
            style={{ width: '100%', padding: '8px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>Locations:</label>
          <div style={{ display: 'flex', gap: '10px' }}>
            <input
              type="text"
              value={locationInput}
              onChange={(e) => setLocationInput(e.target.value)}
              style={{ flex: 1, padding: '8px' }}
            />
            <button type="button" onClick={handleAddLocation} style={{ padding: '8px 15px' }}>
              Add Location
            </button>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px', marginTop: '5px' }}>
            {newPlan.locations.map((location, index) => (
              <span key={index} style={{ background: '#eee', padding: '5px 10px', borderRadius: '15px' }}>
                {location}
                <button type="button" onClick={() => handleRemoveLocation(index)} style={{ marginLeft: '5px', background: 'none', border: 'none', cursor: 'pointer' }}>
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>Start Date:</label>
          <input
            type="date"
            name="start_date"
            value={newPlan.start_date}
            onChange={handleInputChange}
            required
            style={{ width: '100%', padding: '8px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>End Date:</label>
          <input
            type="date"
            name="end_date"
            value={newPlan.end_date}
            onChange={handleInputChange}
            required
            style={{ width: '100%', padding: '8px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>Activities:</label>
          <div style={{ display: 'flex', gap: '10px' }}>
            <input
              type="text"
              value={activityInput}
              onChange={(e) => setActivityInput(e.target.value)}
              style={{ flex: 1, padding: '8px' }}
            />
            <button type="button" onClick={handleAddActivity} style={{ padding: '8px 15px' }}>
              Add Activity
            </button>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px', marginTop: '5px' }}>
            {newPlan.activities.map((activity, index) => (
              <span key={index} style={{ background: '#eee', padding: '5px 10px', borderRadius: '15px' }}>
                {activity}
                <button type="button" onClick={() => handleRemoveActivity(index)} style={{ marginLeft: '5px', background: 'none', border: 'none', cursor: 'pointer' }}>
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>Description:</label>
          <textarea
            name="description"
            value={newPlan.description}
            onChange={handleInputChange}
            style={{ width: '100%', padding: '8px', minHeight: '100px' }}
          />
        </div>
        <button type="submit" style={{ padding: '10px 15px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px' }}>
          {editingId ? 'Update Plan' : 'Add Plan'}
        </button>
        {editingId && (
          <button type="button" onClick={() => {
            setNewPlan({
              name: '',
              locations: [],
              start_date: '',
              end_date: '',
              activities: [],
              description: ''
            });
            setEditingId(null);
          }} style={{ marginLeft: '10px', padding: '10px 15px', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '4px' }}>
            Cancel
          </button>
        )}
      </form>
      
      <h3>Your Journey Plans</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f8f9fa' }}>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Name</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Locations</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Dates</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Activities</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Description</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {plans.map((plan) => (
            <tr key={plan.id} style={{ border: '1px solid #ddd' }}>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{plan.name}</td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                {plan.locations && JSON.parse(plan.locations).map((location, i) => (
                  <div key={i} style={{ margin: '2px 0' }}>{location}</div>
                ))}
              </td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                {new Date(plan.start_date).toLocaleDateString()} - {new Date(plan.end_date).toLocaleDateString()}
              </td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                {plan.activities && JSON.parse(plan.activities).map((activity, i) => (
                  <div key={i} style={{ margin: '2px 0' }}>{activity}</div>
                ))}
              </td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{plan.description}</td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                <button onClick={() => handleEdit(plan)} style={{ marginRight: '5px', padding: '5px 10px', backgroundColor: '#ffc107', border: 'none', borderRadius: '4px' }}>
                  Edit
                </button>
                <button onClick={() => handleDelete(plan.id)} style={{ padding: '5px 10px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px' }}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default JourneyPlans;