import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const TravelLogs = ({ user }) => {
  const [logs, setLogs] = useState([]);
  const [newLog, setNewLog] = useState({
    title: '',
    description: '',
    start_date: '',
    end_date: '',
    tags: []
  });
  const [editingId, setEditingId] = useState(null);
  const [tagInput, setTagInput] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:5000/api/travel-logs', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setLogs(response.data);
      } catch (err) {
        console.error(err);
        if (err.response?.status === 401) {
          navigate('/');
        }
      }
    };
    
    fetchLogs();
  }, [navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewLog({ ...newLog, [name]: value });
  };

  const handleAddTag = () => {
    if (tagInput.trim()) {
      setNewLog({
        ...newLog,
        tags: [...newLog.tags, tagInput.trim()]
      });
      setTagInput('');
    }
  };

  const handleRemoveTag = (index) => {
    const updatedTags = newLog.tags.filter((_, i) => i !== index);
    setNewLog({ ...newLog, tags: updatedTags });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      
      if (editingId) {
        await axios.put(`http://localhost:5000/api/travel-logs/${editingId}`, newLog, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } else {
        await axios.post('http://localhost:5000/api/travel-logs', newLog, {
          headers: { Authorization: `Bearer ${token}` }
        });
      }
      
      // Refresh logs
      const response = await axios.get('http://localhost:5000/api/travel-logs', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setLogs(response.data);
      
      // Reset form
      setNewLog({
        title: '',
        description: '',
        start_date: '',
        end_date: '',
        tags: []
      });
      setEditingId(null);
    } catch (err) {
      console.error(err);
    }
  };

  const handleEdit = (log) => {
    setNewLog({
      title: log.title,
      description: log.description,
      start_date: log.start_date,
      end_date: log.end_date,
      tags: log.tags || []
    });
    setEditingId(log.id);
  };

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/travel-logs/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      // Refresh logs
      const response = await axios.get('http://localhost:5000/api/travel-logs', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setLogs(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Travel Logs</h2>
      <h3>Welcome, {user?.username}!</h3>
      
      <form onSubmit={handleSubmit} style={{ marginBottom: '30px', padding: '20px', border: '1px solid #ddd', borderRadius: '5px' }}>
        <h3>{editingId ? 'Edit Log' : 'Add New Log'}</h3>
        <div style={{ marginBottom: '10px' }}>
          <label>Title:</label>
          <input
            type="text"
            name="title"
            value={newLog.title}
            onChange={handleInputChange}
            required
            style={{ width: '100%', padding: '8px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>Description:</label>
          <textarea
            name="description"
            value={newLog.description}
            onChange={handleInputChange}
            required
            style={{ width: '100%', padding: '8px', minHeight: '100px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>Start Date:</label>
          <input
            type="date"
            name="start_date"
            value={newLog.start_date}
            onChange={handleInputChange}
            required
            style={{ width: '100%', padding: '8px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>End Date:</label>
          <input
            type="date"
            name="end_date"
            value={newLog.end_date}
            onChange={handleInputChange}
            required
            style={{ width: '100%', padding: '8px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label>Tags:</label>
          <div style={{ display: 'flex', gap: '10px' }}>
            <input
              type="text"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              style={{ flex: 1, padding: '8px' }}
            />
            <button type="button" onClick={handleAddTag} style={{ padding: '8px 15px' }}>
              Add Tag
            </button>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px', marginTop: '5px' }}>
            {newLog.tags.map((tag, index) => (
              <span key={index} style={{ background: '#eee', padding: '5px 10px', borderRadius: '15px' }}>
                {tag}
                <button type="button" onClick={() => handleRemoveTag(index)} style={{ marginLeft: '5px', background: 'none', border: 'none', cursor: 'pointer' }}>
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>
        <button type="submit" style={{ padding: '10px 15px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px' }}>
          {editingId ? 'Update Log' : 'Add Log'}
        </button>
        {editingId && (
          <button type="button" onClick={() => {
            setNewLog({
              title: '',
              description: '',
              start_date: '',
              end_date: '',
              tags: []
            });
            setEditingId(null);
          }} style={{ marginLeft: '10px', padding: '10px 15px', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '4px' }}>
            Cancel
          </button>
        )}
      </form>
      
      <h3>Your Travel Logs</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f8f9fa' }}>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Title</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Description</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Dates</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Tags</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log) => (
            <tr key={log.id} style={{ border: '1px solid #ddd' }}>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{log.title}</td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{log.description}</td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                {new Date(log.start_date).toLocaleDateString()} - {new Date(log.end_date).toLocaleDateString()}
              </td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                {log.tags && JSON.parse(log.tags).map((tag, i) => (
                  <span key={i} style={{ display: 'inline-block', background: '#eee', padding: '3px 8px', borderRadius: '15px', margin: '2px' }}>
                    {tag}
                  </span>
                ))}
              </td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                <button onClick={() => handleEdit(log)} style={{ marginRight: '5px', padding: '5px 10px', backgroundColor: '#ffc107', border: 'none', borderRadius: '4px' }}>
                  Edit
                </button>
                <button onClick={() => handleDelete(log.id)} style={{ padding: '5px 10px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px' }}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TravelLogs;